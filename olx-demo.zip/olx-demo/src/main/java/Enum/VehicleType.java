package Enum;

public enum VehicleType {
    TWO_WHEELER,FOUR_WHEELER
}
